package Atividade5;

public class express�o {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
